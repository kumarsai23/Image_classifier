# image-classification

Model which is essential to the satellites to identify the places and also imp for robots and many more day to day life applications
